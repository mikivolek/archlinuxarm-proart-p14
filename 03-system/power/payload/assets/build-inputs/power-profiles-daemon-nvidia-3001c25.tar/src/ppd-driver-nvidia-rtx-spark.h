/*
 * Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 */

#pragma once

#include "ppd-driver-cpu.h"

#define PPD_TYPE_DRIVER_NVIDIA_RTX_SPARK (ppd_driver_nvidia_rtx_spark_get_type ())
G_DECLARE_FINAL_TYPE (PpdDriverNvidiaRtxSpark, ppd_driver_nvidia_rtx_spark, PPD, DRIVER_NVIDIA_RTX_SPARK, PpdDriverCpu)
