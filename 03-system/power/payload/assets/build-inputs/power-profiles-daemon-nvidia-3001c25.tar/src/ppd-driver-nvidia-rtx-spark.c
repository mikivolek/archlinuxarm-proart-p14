/*
 * Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as published by
 * the Free Software Foundation.
 *
 */

#define G_LOG_DOMAIN "CpuDriver"

#include <string.h>

#include "ppd-utils.h"
#include "ppd-driver-nvidia-rtx-spark.h"

#define DMI_ENTRY_DIR "/sys/firmware/dmi/entries/"
#define DMI_PROCESSOR_INFORMATION_TYPE 4
#define DMI_PROCESSOR_VERSION_OFFSET 0x10
#define RTX_SPARK_PROCESSOR_VERSION_PREFIX "NVIDIA RTX Spark"
#define CPUFREQ_POLICY_DIR "/sys/devices/system/cpu/cpufreq/"
#define CPPC_CPUFREQ_DRIVER "cppc_cpufreq"
#define RTX_SPARK_PERFORMANCE_CORE_MIN_MAX_KHZ 3000000

#define RTX_SPARK_EFFICIENCY_EPP_PERFORMANCE "5"
#define RTX_SPARK_EFFICIENCY_EPP_BALANCED "76"
#define RTX_SPARK_EFFICIENCY_EPP_POWER_SAVER "76"

#define RTX_SPARK_PERFORMANCE_EPP_PERFORMANCE "5"
#define RTX_SPARK_PERFORMANCE_EPP_BALANCED "114"
#define RTX_SPARK_PERFORMANCE_EPP_POWER_SAVER "153"

struct _PpdDriverNvidiaRtxSpark
{
  PpdDriverCpu  parent_instance;

  PpdProfile activated_profile;
  GPtrArray *efficiency_epp_devices; /* Array of paths */
  GPtrArray *performance_epp_devices; /* Array of paths */
  GPtrArray *governor_devices; /* Array of paths */
  gboolean on_battery;
};

G_DEFINE_TYPE (PpdDriverNvidiaRtxSpark, ppd_driver_nvidia_rtx_spark, PPD_TYPE_DRIVER_CPU)

static gboolean ppd_driver_nvidia_rtx_spark_activate_profile (PpdDriver                  *driver,
                                                              PpdProfile                  profile,
                                                              PpdProfileActivationReason  reason,
                                                              GError                    **error);

static GObject*
ppd_driver_nvidia_rtx_spark_constructor (GType                  type,
                                         guint                  n_construct_params,
                                         GObjectConstructParam *construct_params)
{
  GObject *object;

  object = G_OBJECT_CLASS (ppd_driver_nvidia_rtx_spark_parent_class)->constructor (type,
                                                                                    n_construct_params,
                                                                                    construct_params);
  g_object_set (object,
                "driver-name", "nvidia_rtx_spark",
                "profiles", PPD_PROFILE_PERFORMANCE | PPD_PROFILE_BALANCED | PPD_PROFILE_POWER_SAVER,
                NULL);

  return object;
}

static gboolean
dmi_processor_is_nvidia_rtx_spark (const guint8 *raw,
                                   gsize         raw_len)
{
  const guint8 *string;
  const guint8 *end;
  const guint8 *nul;
  guint8 formatted_len;
  guint8 string_index;

  if (raw_len <= DMI_PROCESSOR_VERSION_OFFSET ||
      raw[0] != DMI_PROCESSOR_INFORMATION_TYPE)
    return FALSE;

  formatted_len = raw[1];
  if (formatted_len <= DMI_PROCESSOR_VERSION_OFFSET ||
      formatted_len >= raw_len)
    return FALSE;

  string_index = raw[DMI_PROCESSOR_VERSION_OFFSET];
  if (string_index == 0)
    return FALSE;

  string = raw + formatted_len;
  end = raw + raw_len;
  for (guint i = 1; i < string_index; i++) {
    nul = memchr (string, '\0', end - string);
    if (!nul || nul == string)
      return FALSE;
    string = nul + 1;
  }

  nul = memchr (string, '\0', end - string);
  if (!nul || nul == string)
    return FALSE;

  return g_str_has_prefix ((const char *) string,
                           RTX_SPARK_PROCESSOR_VERSION_PREFIX);
}

static gboolean
is_nvidia_rtx_spark (void)
{
  g_autoptr(GDir) dir = NULL;
  g_autofree char *entry_dir = NULL;
  const char *dirname;

  entry_dir = ppd_utils_get_sysfs_path (DMI_ENTRY_DIR);
  dir = g_dir_open (entry_dir, 0, NULL);
  if (!dir)
    return FALSE;

  while ((dirname = g_dir_read_name (dir)) != NULL) {
    g_autofree char *raw_path = NULL;
    g_autofree char *raw = NULL;
    gsize raw_len;

    if (!g_str_has_prefix (dirname, "4-"))
      continue;

    raw_path = g_build_filename (entry_dir, dirname, "raw", NULL);
    if (!g_file_get_contents (raw_path, &raw, &raw_len, NULL))
      continue;

    if (dmi_processor_is_nvidia_rtx_spark ((const guint8 *) raw, raw_len))
      return TRUE;
  }

  return FALSE;
}

static gboolean
available_governors_has (const char *available,
                         const char *governor)
{
  g_auto(GStrv) governors = NULL;

  governors = g_strsplit_set (available, " \n\t", -1);
  return g_strv_contains ((const char * const *) governors, governor);
}

static gboolean
available_governors_valid (const char *available)
{
  return available_governors_has (available, "performance") &&
         available_governors_has (available, "schedutil");
}

static PpdProbeResult
probe_nvidia_rtx_spark (PpdDriverNvidiaRtxSpark *self)
{
  g_autoptr(GDir) dir = NULL;
  g_autofree char *policy_dir = NULL;
  const char *dirname;

  policy_dir = ppd_utils_get_sysfs_path (CPUFREQ_POLICY_DIR);
  dir = g_dir_open (policy_dir, 0, NULL);
  if (!dir) {
    g_debug ("Could not open %s", policy_dir);
    return PPD_PROBE_RESULT_FAIL;
  }

  while ((dirname = g_dir_read_name (dir)) != NULL) {
    g_autofree char *base = NULL;
    g_autofree char *driver_path = NULL;
    g_autofree char *driver = NULL;
    g_autofree char *epp = NULL;
    g_autofree char *governor = NULL;
    g_autofree char *available_governors_path = NULL;
    g_autofree char *available_governors = NULL;
    g_autofree char *current = NULL;
    g_autofree char *current_governor = NULL;
    g_autofree char *max_freq_path = NULL;
    g_autofree char *max_freq = NULL;
    char *end = NULL;
    guint64 max_freq_khz;
    gboolean is_performance_core;
    GPtrArray **epp_devices;
    g_autoptr(GError) error = NULL;

    base = g_build_filename (policy_dir,
                             dirname,
                             NULL);

    driver_path = g_build_filename (base,
                                    "scaling_driver",
                                    NULL);
    if (!g_file_get_contents (driver_path, &driver, NULL, NULL))
      continue;
    driver = g_strchomp (driver);
    if (g_strcmp0 (driver, CPPC_CPUFREQ_DRIVER) != 0)
      continue;

    epp = g_build_filename (base,
                            "energy_performance_preference_val",
                            NULL);
    if (!g_file_test (epp, G_FILE_TEST_EXISTS))
      continue;

    governor = g_build_filename (base,
                                 "scaling_governor",
                                 NULL);
    if (!g_file_test (governor, G_FILE_TEST_EXISTS))
      continue;

    max_freq_path = g_build_filename (base,
                                      "cpuinfo_max_freq",
                                      NULL);
    if (!g_file_get_contents (max_freq_path, &max_freq, NULL, NULL)) {
      g_debug ("CPPC policy %s does not expose cpuinfo_max_freq", dirname);
      continue;
    }
    max_freq = g_strchomp (max_freq);
    max_freq_khz = g_ascii_strtoull (max_freq, &end, 10);
    if (end == max_freq || *end != '\0') {
      g_debug ("CPPC policy %s exposes invalid cpuinfo_max_freq '%s'", dirname, max_freq);
      continue;
    }
    is_performance_core = max_freq_khz >= RTX_SPARK_PERFORMANCE_CORE_MIN_MAX_KHZ;

    available_governors_path = g_build_filename (base,
                                                 "scaling_available_governors",
                                                 NULL);
    if (!g_file_get_contents (available_governors_path, &available_governors, NULL, NULL) ||
        !available_governors_valid (available_governors)) {
      g_debug ("CPPC policy %s does not expose expected governors", dirname);
      continue;
    }

    if (!g_file_get_contents (epp, &current, NULL, NULL))
      continue;
    current = g_strchomp (current);
    if (!ppd_utils_write (epp, current, &error)) {
      g_debug ("Could not validate CPPC EPP writes for %s: %s", dirname, error->message);
      continue;
    }

    if (!g_file_get_contents (governor, &current_governor, NULL, NULL))
      continue;
    current_governor = g_strchomp (current_governor);
    if (!ppd_utils_write (governor, current_governor, &error)) {
      g_debug ("Could not validate CPUFreq governor writes for %s: %s", dirname, error->message);
      continue;
    }

    epp_devices = is_performance_core ?
                  &self->performance_epp_devices :
                  &self->efficiency_epp_devices;
    if (!*epp_devices)
      *epp_devices = g_ptr_array_new_with_free_func (g_free);
    if (!self->governor_devices)
      self->governor_devices = g_ptr_array_new_with_free_func (g_free);

    g_ptr_array_add (*epp_devices, g_steal_pointer (&epp));
    g_ptr_array_add (self->governor_devices, g_steal_pointer (&governor));
  }

  if (((self->efficiency_epp_devices &&
        self->efficiency_epp_devices->len) ||
       (self->performance_epp_devices &&
        self->performance_epp_devices->len)) &&
      self->governor_devices &&
      self->governor_devices->len)
    return PPD_PROBE_RESULT_SUCCESS;

  return PPD_PROBE_RESULT_FAIL;
}

static PpdProbeResult
ppd_driver_nvidia_rtx_spark_probe (PpdDriver  *driver)
{
  PpdDriverNvidiaRtxSpark *self = PPD_DRIVER_NVIDIA_RTX_SPARK (driver);
  PpdProbeResult ret;

  if (!is_nvidia_rtx_spark ())
    return PPD_PROBE_RESULT_FAIL;

  ret = probe_nvidia_rtx_spark (self);

  g_debug ("%s NVIDIA RTX Spark CPPC cpufreq settings",
           ret == PPD_PROBE_RESULT_SUCCESS ? "Found" : "Didn't find");
  return ret;
}

static const char *
profile_to_epp (PpdProfile profile,
                gboolean   performance_core)
{
  switch (profile) {
  case PPD_PROFILE_POWER_SAVER:
    return performance_core ?
           RTX_SPARK_PERFORMANCE_EPP_POWER_SAVER :
           RTX_SPARK_EFFICIENCY_EPP_POWER_SAVER;
  case PPD_PROFILE_BALANCED:
    return performance_core ?
           RTX_SPARK_PERFORMANCE_EPP_BALANCED :
           RTX_SPARK_EFFICIENCY_EPP_BALANCED;
  case PPD_PROFILE_PERFORMANCE:
    return performance_core ?
           RTX_SPARK_PERFORMANCE_EPP_PERFORMANCE :
           RTX_SPARK_EFFICIENCY_EPP_PERFORMANCE;
  }

  g_return_val_if_reached (NULL);
}

static const char *
profile_to_governor (PpdProfile profile,
                     gboolean   on_battery)
{
  switch (profile) {
  case PPD_PROFILE_POWER_SAVER:
    return "schedutil";
  case PPD_PROFILE_BALANCED:
    return on_battery ? "schedutil" : "performance";
  case PPD_PROFILE_PERFORMANCE:
    return "performance";
  }

  g_return_val_if_reached (NULL);
}

static gboolean
apply_profile_to_devices (PpdDriver   *driver,
                          PpdProfile   profile,
                          GError     **error)
{
  PpdDriverNvidiaRtxSpark *self = PPD_DRIVER_NVIDIA_RTX_SPARK (driver);
  const char *governor;

  if (profile == PPD_PROFILE_UNSET)
    return TRUE;

  g_return_val_if_fail (self->efficiency_epp_devices != NULL ||
                        self->performance_epp_devices != NULL, FALSE);
  g_return_val_if_fail (self->governor_devices != NULL, FALSE);
  g_return_val_if_fail (self->governor_devices->len != 0, FALSE);

  if (self->efficiency_epp_devices &&
      !ppd_utils_write_files (self->efficiency_epp_devices,
                              profile_to_epp (profile, FALSE),
                              error))
      return FALSE;

  if (self->performance_epp_devices &&
      !ppd_utils_write_files (self->performance_epp_devices,
                              profile_to_epp (profile, TRUE),
                              error))
      return FALSE;

  governor = profile_to_governor (profile, self->on_battery);
  if (!ppd_utils_write_files (self->governor_devices, governor, error))
    return FALSE;

  return TRUE;
}

static gboolean
ppd_driver_nvidia_rtx_spark_activate_profile (PpdDriver                  *driver,
                                              PpdProfile                  profile,
                                              PpdProfileActivationReason  reason,
                                              GError                    **error)
{
  PpdDriverNvidiaRtxSpark *self = PPD_DRIVER_NVIDIA_RTX_SPARK (driver);
  gboolean ret;

  ret = apply_profile_to_devices (driver, profile, error);
  if (!ret && self->activated_profile != PPD_PROFILE_UNSET) {
    g_autoptr(GError) local_error = NULL;

    if (!apply_profile_to_devices (driver, self->activated_profile, &local_error))
      g_warning ("Failed to restore previous CPPC cpufreq profile: %s", local_error->message);
    return ret;
  }

  if (ret)
    self->activated_profile = profile;

  return ret;
}

static gboolean
ppd_driver_nvidia_rtx_spark_power_changed (PpdDriver             *driver,
                                           PpdPowerChangedReason  reason,
                                           GError               **error)
{
  PpdDriverNvidiaRtxSpark *self = PPD_DRIVER_NVIDIA_RTX_SPARK (driver);

  switch (reason) {
  case PPD_POWER_CHANGED_REASON_UNKNOWN:
  case PPD_POWER_CHANGED_REASON_AC:
    self->on_battery = FALSE;
    break;
  case PPD_POWER_CHANGED_REASON_BATTERY:
    self->on_battery = TRUE;
    break;
  default:
    g_return_val_if_reached (FALSE);
  }

  return apply_profile_to_devices (driver,
                                   self->activated_profile,
                                   error);
}

static gboolean
ppd_driver_nvidia_rtx_spark_prepare_for_sleep (PpdDriver  *driver,
                                               gboolean    start,
                                               GError    **error)
{
  PpdDriverNvidiaRtxSpark *self = PPD_DRIVER_NVIDIA_RTX_SPARK (driver);

  if (start)
    return TRUE;

  return ppd_driver_nvidia_rtx_spark_activate_profile (driver,
                                                       self->activated_profile,
                                                       PPD_PROFILE_ACTIVATION_REASON_RESUME,
                                                       error);
}

static void
ppd_driver_nvidia_rtx_spark_finalize (GObject *object)
{
  PpdDriverNvidiaRtxSpark *driver;

  driver = PPD_DRIVER_NVIDIA_RTX_SPARK (object);
  g_clear_pointer (&driver->efficiency_epp_devices, g_ptr_array_unref);
  g_clear_pointer (&driver->performance_epp_devices, g_ptr_array_unref);
  g_clear_pointer (&driver->governor_devices, g_ptr_array_unref);
  G_OBJECT_CLASS (ppd_driver_nvidia_rtx_spark_parent_class)->finalize (object);
}

static void
ppd_driver_nvidia_rtx_spark_class_init (PpdDriverNvidiaRtxSparkClass *klass)
{
  GObjectClass *object_class;
  PpdDriverClass *driver_class;

  object_class = G_OBJECT_CLASS (klass);
  object_class->constructor = ppd_driver_nvidia_rtx_spark_constructor;
  object_class->finalize = ppd_driver_nvidia_rtx_spark_finalize;

  driver_class = PPD_DRIVER_CLASS (klass);
  driver_class->probe = ppd_driver_nvidia_rtx_spark_probe;
  driver_class->activate_profile = ppd_driver_nvidia_rtx_spark_activate_profile;
  driver_class->prepare_to_sleep = ppd_driver_nvidia_rtx_spark_prepare_for_sleep;
  driver_class->power_changed = ppd_driver_nvidia_rtx_spark_power_changed;
}

static void
ppd_driver_nvidia_rtx_spark_init (PpdDriverNvidiaRtxSpark *self)
{
}
