/*
 * SPDX-FileCopyrightText: Copyright (c) 1999-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: MIT
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#define  __NO_VERSION__

#include "os-interface.h"
#include "nv-linux.h"
#include "nv-reg.h"
#include <linux/iommu.h>

#if IS_ENABLED(CONFIG_DRM)
#include <drm/drm_device.h>
#include <drm/drm_drv.h>

#if defined(NV_DRM_DRMP_H_PRESENT)
#include <drm/drmP.h>
#endif

#include <drm/drm_gem.h>
#endif /* IS_ENABLED(CONFIG_DRM) */

#define NV_DMA_DEV_PRINTF(debuglevel, dma_dev, format, ... )                \
    nv_printf(debuglevel, "NVRM: %s: " format,                              \
              (((dma_dev) && ((dma_dev)->dev)) ? dev_name((dma_dev)->dev) : \
                                                 NULL),                     \
              ## __VA_ARGS__)

NvU32 nv_dma_remap_peer_mmio = NV_DMA_REMAP_PEER_MMIO_ENABLE;

NV_STATUS   nv_create_dma_map_scatterlist (nv_dma_map_t *dma_map);
void        nv_destroy_dma_map_scatterlist(nv_dma_map_t *dma_map);
NV_STATUS   nv_map_dma_map_scatterlist    (nv_dma_map_t *dma_map);
void        nv_unmap_dma_map_scatterlist  (nv_dma_map_t *dma_map);
static void nv_dma_unmap_contig           (nv_dma_map_t *dma_map);
static void nv_dma_unmap_scatterlist      (nv_dma_map_t *dma_map);

static enum dma_data_direction nv_dma_get_direction
(
    nv_dma_map_t *dma_map
)
{
    return dma_map->bReadOnlyDeviceMap ? DMA_TO_DEVICE : DMA_BIDIRECTIONAL;
}

static inline NvBool nv_dma_is_addressable(
    nv_dma_device_t *dma_dev,
    NvU64 start,
    NvU64 size
)
{
    NvU64 limit = start + size - 1;

    return (start >= dma_dev->addressable_range.start) &&
           (limit <= dma_dev->addressable_range.limit) &&
           (limit >= start);
}

static NV_STATUS nv_dma_map_contig(
    nv_dma_device_t *dma_dev,
    nv_dma_map_t *dma_map,
    NvU64 *va
)
{
    enum dma_data_direction direction = nv_dma_get_direction(dma_map);

    *va = dma_map_page_attrs(dma_map->dev, dma_map->pages[0], 0,
                             dma_map->page_count * PAGE_SIZE,
                             direction,
                             (dma_map->cache_type == NV_MEMORY_UNCACHED) ?
                              DMA_ATTR_SKIP_CPU_SYNC : 0);
    if (dma_mapping_error(dma_map->dev, *va))
    {
        return NV_ERR_OPERATING_SYSTEM;
    }

    dma_map->mapping.contig.dma_addr = *va;

    if (!nv_dma_is_addressable(dma_dev, *va, dma_map->page_count * PAGE_SIZE))
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "DMA address not in addressable range of device "
                "(0x%llx-0x%llx, 0x%llx-0x%llx)\n",
                *va, *va + (dma_map->page_count * PAGE_SIZE - 1),
                dma_dev->addressable_range.start,
                dma_dev->addressable_range.limit);
        nv_dma_unmap_contig(dma_map);
        return NV_ERR_INVALID_ADDRESS;
    }

    return NV_OK;
}

static void nv_dma_unmap_contig(nv_dma_map_t *dma_map)
{
    enum dma_data_direction direction = nv_dma_get_direction(dma_map);

    dma_unmap_page_attrs(dma_map->dev, dma_map->mapping.contig.dma_addr,
                         dma_map->page_count * PAGE_SIZE,
                         direction,
                         (dma_map->cache_type == NV_MEMORY_UNCACHED) ?
                          DMA_ATTR_SKIP_CPU_SYNC : 0);
}

static void nv_fill_scatterlist
(
    struct scatterlist *sgl,
    struct page **pages,
    unsigned int page_count
)
{
    unsigned int i;
    struct scatterlist *sg;
#if defined(for_each_sg)
    for_each_sg(sgl, sg, page_count, i)
    {
        sg_set_page(sg, pages[i], PAGE_SIZE, 0);
    }
#else
    for (i = 0; i < page_count; i++)
    {
        sg = &(sgl)[i];
        sg->page = pages[i];
        sg->length = PAGE_SIZE;
        sg->offset = 0;
    }
#endif
}

NV_STATUS nv_create_dma_map_scatterlist(nv_dma_map_t *dma_map)
{
    /*
     * We need to split our mapping into at most 4GB - PAGE_SIZE chunks.
     * The Linux kernel stores the length (and offset) of a scatter-gather
     * segment as an unsigned int, so it will overflow if we try to do
     * anything larger.
     */
    NV_STATUS status;
    nv_dma_submap_t *submap;
    NvU32 i;

#if defined(NV_SG_ALLOC_TABLE_FROM_PAGES_SEGMENT_PRESENT)
    dma_map->mapping.discontig.submap_count = 1;
#else
    NvU64 allocated_size = 0;
    NvU64 num_submaps = dma_map->page_count + NV_DMA_SUBMAP_MAX_PAGES - 1;
    NvU64 total_size = dma_map->page_count << PAGE_SHIFT;

    /*
     * This turns into 64-bit division, which the ARMv7 kernel doesn't provide
     * implicitly. Instead, we need to use the platform's do_div() to perform
     * the division.
     */
    do_div(num_submaps, NV_DMA_SUBMAP_MAX_PAGES);

    WARN_ON(NvU64_HI32(num_submaps) != 0);

    if (dma_map->import_sgt && (num_submaps != 1))
    {
        return -EINVAL;
    }

    dma_map->mapping.discontig.submap_count = NvU64_LO32(num_submaps);
#endif

    status = os_alloc_mem((void **)&dma_map->mapping.discontig.submaps,
        sizeof(nv_dma_submap_t) * dma_map->mapping.discontig.submap_count);
    if (status != NV_OK)
    {
        return status;
    }

    os_mem_set((void *)dma_map->mapping.discontig.submaps, 0,
        sizeof(nv_dma_submap_t) * dma_map->mapping.discontig.submap_count);

    /* If we have an imported SGT, just use that directly. */
    if (dma_map->import_sgt)
    {
        dma_map->mapping.discontig.submaps[0].page_count = dma_map->page_count;
        dma_map->mapping.discontig.submaps[0].sgt = *dma_map->import_sgt;
        dma_map->mapping.discontig.submaps[0].imported = NV_TRUE;

        return status;
    }

    NV_FOR_EACH_DMA_SUBMAP(dma_map, submap, i)
    {
#if defined(NV_SG_ALLOC_TABLE_FROM_PAGES_SEGMENT_PRESENT)
        submap->page_count = (NvU32)dma_map->page_count;
#else
        NvU64 submap_size = NV_MIN(NV_DMA_SUBMAP_MAX_PAGES << PAGE_SHIFT,
                                   total_size - allocated_size);

        submap->page_count = (NvU32)(submap_size >> PAGE_SHIFT);
#endif

        status = NV_ALLOC_DMA_SUBMAP_SCATTERLIST(dma_map, submap, i);
        if (status != NV_OK)
        {
            submap->page_count = 0;
            break;
        }

#if defined(NV_DOM0_KERNEL_PRESENT)
        {
            NvU64 page_idx = NV_DMA_SUBMAP_IDX_TO_PAGE_IDX(i);
            nv_fill_scatterlist(submap->sgt.sgl,
                &dma_map->pages[page_idx], submap->page_count);
        }
#endif

#if !(defined(NV_SG_ALLOC_TABLE_FROM_PAGES_SEGMENT_PRESENT))
        allocated_size += submap_size;
#endif
    }

#if !(defined(NV_SG_ALLOC_TABLE_FROM_PAGES_SEGMENT_PRESENT))
    WARN_ON(allocated_size != total_size);
#endif

    if (status != NV_OK)
    {
        nv_destroy_dma_map_scatterlist(dma_map);
    }

    return status;
}

NV_STATUS nv_map_dma_map_scatterlist(nv_dma_map_t *dma_map)
{
    NV_STATUS status = NV_OK;
    nv_dma_submap_t *submap;
    NvU64 i;
    enum dma_data_direction direction = nv_dma_get_direction(dma_map);

    NV_FOR_EACH_DMA_SUBMAP(dma_map, submap, i)
    {
        /* Imported SGTs will have already been mapped by the exporter. */
        submap->sg_map_count = submap->imported ?
            submap->sgt.orig_nents :
            dma_map_sg(dma_map->dev,
                       submap->sgt.sgl,
                       submap->sgt.orig_nents,
                       direction);
        if (submap->sg_map_count == 0)
        {
            status = NV_ERR_OPERATING_SYSTEM;
            break;
        }
    }

    if (status != NV_OK)
    {
        nv_unmap_dma_map_scatterlist(dma_map);
    }

    return status;
}

void nv_unmap_dma_map_scatterlist(nv_dma_map_t *dma_map)
{
    nv_dma_submap_t *submap;
    NvU64 i;
    enum dma_data_direction direction = nv_dma_get_direction(dma_map);

    NV_FOR_EACH_DMA_SUBMAP(dma_map, submap, i)
    {
        if (submap->sg_map_count == 0)
        {
            break;
        }

        if (submap->imported)
        {
            /* Imported SGTs will be unmapped by the exporter. */
            continue;
        }

        dma_unmap_sg(dma_map->dev, submap->sgt.sgl,
                submap->sgt.orig_nents,
                direction);
    }
}

void nv_destroy_dma_map_scatterlist(nv_dma_map_t *dma_map)
{
    nv_dma_submap_t *submap;
    NvU64 i;

    NV_FOR_EACH_DMA_SUBMAP(dma_map, submap, i)
    {
        if ((submap->page_count == 0) || submap->imported)
        {
            break;
        }

        sg_free_table(&submap->sgt);
    }

    os_free_mem(dma_map->mapping.discontig.submaps);
}

static void nv_load_dma_map_scatterlist(
    nv_dma_map_t *dma_map,
    NvU64 *va_array
)
{
    unsigned int i, j;
    struct scatterlist *sg;
    nv_dma_submap_t *submap;
    NvU64 sg_addr, sg_off, sg_len, k, l = 0;

    NV_FOR_EACH_DMA_SUBMAP(dma_map, submap, i)
    {
        for_each_sg(submap->sgt.sgl, sg, submap->sg_map_count, j)
        {
            /*
             * It is possible for pci_map_sg() to merge scatterlist entries, so
             * make sure we account for that here.
             */
            for (sg_addr = sg_dma_address(sg), sg_len = sg_dma_len(sg),
                    sg_off = 0, k = 0;
                 (sg_off < sg_len) && (k < submap->page_count);
                 sg_off += PAGE_SIZE, l++, k++)
            {
                va_array[l] = sg_addr + sg_off;
            }
        }
    }
}

static NV_STATUS nv_dma_map_scatterlist(
    nv_dma_device_t *dma_dev,
    nv_dma_map_t    *dma_map,
    NvU64           *va_array
)
{
    NV_STATUS status;
    NvU64 i;

    status = nv_create_dma_map_scatterlist(dma_map);
    if (status != NV_OK)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "Failed to allocate DMA mapping scatterlist!\n");
        return status;
    }

    status = nv_map_dma_map_scatterlist(dma_map);
    if (status != NV_OK)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "Failed to create a DMA mapping!\n");
        nv_destroy_dma_map_scatterlist(dma_map);
        return status;
    }

    nv_load_dma_map_scatterlist(dma_map, va_array);

    for (i = 0; i < dma_map->page_count; i++)
    {
        if (!nv_dma_is_addressable(dma_dev, va_array[i], PAGE_SIZE))
        {
            NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                    "DMA address not in addressable range of device "
                    "(0x%llx, 0x%llx-0x%llx)\n",
                    va_array[i], dma_dev->addressable_range.start,
                    dma_dev->addressable_range.limit);
            nv_dma_unmap_scatterlist(dma_map);
            return NV_ERR_INVALID_ADDRESS;
        }
    }

    return NV_OK;
}

static void nv_dma_unmap_scatterlist(nv_dma_map_t *dma_map)
{
    nv_unmap_dma_map_scatterlist(dma_map);
    nv_destroy_dma_map_scatterlist(dma_map);
}

NV_STATUS NV_API_CALL nv_dma_map_sgt(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64           *va_array,
    NvU32            cache_type,
    NvBool           bReadOnlyDeviceMap,
    void           **priv
)
{
    NV_STATUS status;
    nv_dma_map_t *dma_map = NULL;

    if (priv == NULL)
    {
        return NV_ERR_NOT_SUPPORTED;
    }

    if (page_count > get_num_physpages())
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "DMA mapping request too large!\n");
        return NV_ERR_INVALID_REQUEST;
    }

    status = os_alloc_mem((void **)&dma_map, sizeof(nv_dma_map_t));
    if (status != NV_OK)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "Failed to allocate nv_dma_map_t!\n");
        return status;
    }

    dma_map->dev = dma_dev->dev;
    dma_map->pages = NULL;
    dma_map->import_sgt = (struct sg_table *) *priv;
    dma_map->page_count = page_count;
    dma_map->contiguous = NV_FALSE;
    dma_map->cache_type = cache_type;
    dma_map->bReadOnlyDeviceMap = bReadOnlyDeviceMap;

    dma_map->mapping.discontig.submap_count = 0;
    status = nv_dma_map_scatterlist(dma_dev, dma_map, va_array);

    if (status != NV_OK)
    {
        os_free_mem(dma_map);
    }
    else
    {
        *priv = dma_map;
    }

    return status;
}

static NV_STATUS NV_API_CALL nv_dma_unmap_sgt(
    nv_dma_device_t *dma_dev,
    void           **priv
)
{
    nv_dma_map_t *dma_map;

    if (priv == NULL)
    {
        return NV_ERR_NOT_SUPPORTED;
    }

    dma_map = *priv;

    *priv = NULL;

    nv_dma_unmap_scatterlist(dma_map);

    os_free_mem(dma_map);

    return NV_OK;
}

static NV_STATUS NV_API_CALL nv_dma_map_pages(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64           *va_array,
    NvBool           contig,
    NvU32            cache_type,
    NvBool           bReadOnlyDeviceMap,
    void           **priv
)
{
    NV_STATUS status;
    nv_dma_map_t *dma_map = NULL;

    if (priv == NULL)
    {
        /*
         * IOMMU path has not been implemented yet to handle
         * anything except a nv_dma_map_t as the priv argument.
         */
        return NV_ERR_NOT_SUPPORTED;
    }

    if (page_count > get_num_physpages())
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "DMA mapping request too large!\n");
        return NV_ERR_INVALID_REQUEST;
    }

    status = os_alloc_mem((void **)&dma_map, sizeof(nv_dma_map_t));
    if (status != NV_OK)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "Failed to allocate nv_dma_map_t!\n");
        return status;
    }

    dma_map->dev = dma_dev->dev;
    dma_map->pages = *priv;
    dma_map->import_sgt = NULL;
    dma_map->page_count = page_count;
    dma_map->contiguous = contig;
    dma_map->cache_type = cache_type;
    dma_map->bReadOnlyDeviceMap = bReadOnlyDeviceMap;

    if (dma_map->page_count > 1 && !dma_map->contiguous)
    {
        dma_map->mapping.discontig.submap_count = 0;
        status = nv_dma_map_scatterlist(dma_dev, dma_map, va_array);
    }
    else
    {
        /*
         * Force single-page mappings to be contiguous to avoid scatterlist
         * overhead.
         */
        dma_map->contiguous = NV_TRUE;

        status = nv_dma_map_contig(dma_dev, dma_map, va_array);
    }

    if (status != NV_OK)
    {
        os_free_mem(dma_map);
    }
    else
    {
        *priv = dma_map;
    }

    return status;
}

static NV_STATUS NV_API_CALL nv_dma_unmap_pages(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64           *va_array,
    void           **priv
)
{
    nv_dma_map_t *dma_map;

    if (priv == NULL)
    {
        /*
         * IOMMU path has not been implemented yet to handle
         * anything except a nv_dma_map_t as the priv argument.
         */
        return NV_ERR_NOT_SUPPORTED;
    }

    dma_map = *priv;

    if (page_count > get_num_physpages())
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "DMA unmapping request too large!\n");
        return NV_ERR_INVALID_REQUEST;
    }

    if (page_count != dma_map->page_count)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_WARNINGS, dma_dev,
                "Requested to DMA unmap %llu pages, but there are %llu "
                "in the mapping\n", page_count, dma_map->page_count);
        return NV_ERR_INVALID_REQUEST;
    }

    *priv = dma_map->pages;

    if (dma_map->contiguous)
    {
        nv_dma_unmap_contig(dma_map);
    }
    else
    {
        nv_dma_unmap_scatterlist(dma_map);
    }

    os_free_mem(dma_map);

    return NV_OK;
}

/*
 * Wrappers used for DMA-remapping an nv_alloc_t during transition to more
 * generic interfaces.
 */
NV_STATUS NV_API_CALL nv_dma_map_alloc
(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64           *va_array,
    NvBool           contig,
    NvBool           bReadOnlyDeviceMap,
    void           **priv
)
{
    NV_STATUS status;
    NvU64 i;
    nv_alloc_t *at = *priv;
    struct page **pages = NULL;
    NvU32 cache_type = NV_MEMORY_CACHED;
    NvU64 pages_size = sizeof(struct page *) * (contig ? 1 : page_count);

    /* If we have an imported SGT, just use that directly. */
    if (at && at->import_sgt)
    {
        *priv = at->import_sgt;
        status = nv_dma_map_sgt(dma_dev, page_count, va_array, at->cache_type,
                                bReadOnlyDeviceMap, priv);
        if (status != NV_OK)
        {
            *priv = at;
        }
        return status;
    }

    /*
     * Convert the nv_alloc_t into a struct page * array for
     * nv_dma_map_pages().
     */
    status = os_alloc_mem((void **)&pages, pages_size);
    if (status != NV_OK)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "Failed to allocate page array for DMA mapping!\n");
        return status;
    }

    os_mem_set(pages, 0, pages_size);

    if (at != NULL)
    {
        WARN_ON(page_count != at->num_pages);

        if (at->flags.user)
        {
            pages[0] = at->user_pages[0];
            if (!contig)
            {
                for (i = 1; i < page_count; i++)
                {
                    pages[i] = at->user_pages[i];
                }
            }
        }
        else if (at->flags.physical && contig)
        {
            /* Supplied pages hold physical address */
            pages[0] = pfn_to_page(PFN_DOWN(va_array[0]));
        }
        cache_type = at->cache_type;
    }

    if (pages[0] == NULL)
    {
        pages[0] = NV_GET_PAGE_STRUCT(va_array[0]);
        if (!contig)
        {
            for (i = 1; i < page_count; i++)
            {
                pages[i] = NV_GET_PAGE_STRUCT(va_array[i]);
            }
        }
    }

    *priv = pages;
    status = nv_dma_map_pages(dma_dev, page_count, va_array, contig, cache_type,
                              bReadOnlyDeviceMap, priv);
    if (status != NV_OK)
    {
        *priv = at;
        os_free_mem(pages);
    }

    return status;
}

NV_STATUS NV_API_CALL nv_dma_unmap_alloc
(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64           *va_array,
    void           **priv
)
{
    NV_STATUS status = NV_OK;
    nv_dma_map_t *dma_map;

    if (priv == NULL)
    {
        return NV_ERR_NOT_SUPPORTED;
    }

    dma_map = *priv;

    if (!dma_map->import_sgt)
    {
        status = nv_dma_unmap_pages(dma_dev, page_count, va_array, priv);
        if (status != NV_OK)
        {
            /*
             * If nv_dma_unmap_pages() fails, we hit an assert condition and the
             * priv argument won't be the page array we allocated in
             * nv_dma_map_alloc(), so we skip the free here. But note that since
             * this is an assert condition it really should never happen.
             */
            return status;
        }

        /* Free the struct page * array allocated by nv_dma_map_alloc() */
        os_free_mem(*priv);
    } else {
        status = nv_dma_unmap_sgt(dma_dev, priv);
    }

    return status;
}

static NvBool nv_dma_use_map_resource
(
    nv_dma_device_t *dma_dev
)
{
    const struct dma_map_ops *ops = get_dma_ops(dma_dev->dev);

    if (nv_dma_remap_peer_mmio == NV_DMA_REMAP_PEER_MMIO_DISABLE)
    {
        return NV_FALSE;
    }

    if (ops == NULL)
    {
        //
        // ops can be NULL on 5.0+ kernels, meaning we can utilize direct dma.
        // On pre-5.0 kernels, ops is assumed to never be NULL.
        //
        return NV_TRUE;
    }

#if defined(NV_DMA_MAP_OPS_HAS_MAP_PHYS)
    return (ops->map_phys != NULL);
#else
    return (ops->map_resource != NULL);
#endif
}

/* DMA-map a peer PCI device's BAR for peer access. */
NV_STATUS NV_API_CALL nv_dma_map_peer
(
    nv_dma_device_t *dma_dev,
    nv_dma_device_t *peer_dma_dev,
    NvU8             nv_bar_index,
    NvU64            page_count,
    NvU64           *va
)
{
    struct pci_dev *peer_pci_dev = to_pci_dev(peer_dma_dev->dev);
    struct resource *res;
    NvU8 bar_index;
    NV_STATUS status;

    if (peer_pci_dev == NULL)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, peer_dma_dev,
            "Not a PCI device");
        return NV_ERR_INVALID_REQUEST;
    }

    bar_index = nv_bar_index_to_os_bar_index(peer_pci_dev, nv_bar_index);
    res = &peer_pci_dev->resource[bar_index];
    if (res->start == 0)
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, peer_dma_dev,
                "Resource %u not valid",
                bar_index);
        return NV_ERR_INVALID_REQUEST;
    }

    if ((*va < res->start) || ((*va + (page_count * PAGE_SIZE)) > res->end))
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, peer_dma_dev,
                "Mapping requested (start = 0x%llx, page_count = 0x%llx)"
                " outside of resource bounds (start = 0x%llx, end = 0x%llx)\n",
                *va, page_count, res->start, res->end);
        return NV_ERR_INVALID_REQUEST;
    }

    if (nv_dma_use_map_resource(dma_dev))
    {
        status = nv_dma_map_mmio(dma_dev, page_count, va);
    }
    else
    {
        /*
         * Best effort - can't map through the iommu but at least try to
         * convert to a bus address.
         */
        NvU64 offset = *va - res->start;
        *va = pci_bus_address(peer_pci_dev, bar_index) + offset;
        status = NV_OK;
    }

    return status;
}

void NV_API_CALL nv_dma_unmap_peer
(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64            va
)
{
    if (nv_dma_use_map_resource(dma_dev))
    {
        nv_dma_unmap_mmio(dma_dev, page_count, va);
    }
}

/* DMA-map another anonymous device's MMIO region for peer access. */
NV_STATUS NV_API_CALL nv_dma_map_mmio
(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64           *va
)
{
    BUG_ON(!va);

    if (nv_dma_use_map_resource(dma_dev))
    {
        NvU64 mmio_addr = *va;
        *va = dma_map_resource(dma_dev->dev, mmio_addr, page_count * PAGE_SIZE,
                               DMA_BIDIRECTIONAL, 0);
        if (dma_mapping_error(dma_dev->dev, *va))
        {
            NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                    "Failed to DMA map MMIO range [0x%llx-0x%llx]\n",
                    mmio_addr, mmio_addr + page_count * PAGE_SIZE - 1);
            return NV_ERR_OPERATING_SYSTEM;
        }
    }
    else
    {
        /*
         * If dma_map_resource is not available, pass through the source address
         * without failing. Further, adjust it using the DMA start address to
         * keep RM's validation schemes happy.
         */
        *va = *va + dma_dev->addressable_range.start;
    }

    return NV_OK;
}

void NV_API_CALL nv_dma_unmap_mmio
(
    nv_dma_device_t *dma_dev,
    NvU64            page_count,
    NvU64            va
)
{
    if (nv_dma_use_map_resource(dma_dev))
    {
        dma_unmap_resource(dma_dev->dev, va, page_count * PAGE_SIZE,
                           DMA_BIDIRECTIONAL, 0);
    }
}

/*
 * Invalidate DMA mapping in CPU caches by "syncing" to the device.
 *
 * This is only implemented for ARM platforms, since other supported
 * platforms are cache coherent and have not required this (we
 * explicitly haven't supported SWIOTLB bounce buffering either where
 * this would be needed).
 */
void NV_API_CALL nv_dma_cache_invalidate
(
    nv_dma_device_t *dma_dev,
    void *priv
)
{
#if defined(NVCPU_AARCH64)
    nv_dma_map_t *dma_map = priv;

    if (dma_map->contiguous)
    {
        dma_sync_single_for_device(dma_dev->dev,
                                   dma_map->mapping.contig.dma_addr,
                                   (size_t) PAGE_SIZE * dma_map->page_count,
                                   DMA_FROM_DEVICE);
    }
    else
    {
        nv_dma_submap_t *submap;
        NvU64 i;

        NV_FOR_EACH_DMA_SUBMAP(dma_map, submap, i)
        {
            dma_sync_sg_for_device(dma_dev->dev,
                                   submap->sgt.sgl,
                                   submap->sgt.orig_nents,
                                   DMA_FROM_DEVICE);
        }
    }
#endif
}

//
// Note: For mapping GPU memory on third-party devices using dma-buf/nv-p2p in CDMM,
// there isn't a kernel API that can be used for page-less coherent memory
// on pre-6.18 kernels. Kernel 6.18 introduces dma_map_phys which doesn't require
// struct page and uses physical addresses directly.
// So this is only a WAR on CDMM for kernels older than 6.18. UVM creates
// ZONE_DEVICE coherent pages for GPU memory in CDMM. RM uses these for DMA mapping.
//
// nv_dma_get_dev_pagemap adds a reference on the ZONE_DEVICE pagemap so the pages
// don't go away when the DMA mapping is in progress.
//
void* NV_API_CALL nv_dma_get_dev_pagemap
(
    NvU64 phys_addr
)
{
#if defined(NV_MEMORY_DEVICE_COHERENT_PRESENT)
    return NV_GET_DEV_PAGEMAP(PHYS_PFN(phys_addr));
#else
    return NULL;
#endif
}

//
// nv_dma_put_dev_pagemap removes the reference on the ZONE_DEVICE pagemap.
//
void NV_API_CALL nv_dma_put_dev_pagemap
(
    void *pgmap
)
{
#if defined(NV_MEMORY_DEVICE_COHERENT_PRESENT)
    if (pgmap != NULL)
    {
        put_dev_pagemap((struct dev_pagemap*) pgmap);
    }
#endif
}

#if IS_ENABLED(CONFIG_DRM)

static inline void
nv_dma_gem_object_put_unlocked(struct drm_gem_object *gem)
{
#if defined(NV_DRM_GEM_OBJECT_PUT_UNLOCK_PRESENT)
    drm_gem_object_put_unlocked(gem);
#else
    drm_gem_object_put(gem);
#endif
}

NV_STATUS NV_API_CALL nv_dma_import_sgt
(
    nv_dma_device_t *dma_dev,
    struct sg_table *sgt,
    struct drm_gem_object *gem
)
{
    if ((dma_dev == NULL) ||
        (sgt == NULL) ||
        (gem == NULL))
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "Import arguments are NULL!\n");
        return NV_ERR_INVALID_ARGUMENT;
    }

    // Prevent the kernel module controlling GEM from being unloaded
    if (!try_module_get(gem->dev->driver->fops->owner))
    {
        NV_DMA_DEV_PRINTF(NV_DBG_ERRORS, dma_dev,
                "Couldn't reference the GEM object's owner!\n");
        return NV_ERR_INVALID_DEVICE;
    }

    // Do nothing with SGT, it is already mapped and pinned by the exporter

    drm_gem_object_get(gem);

    return NV_OK;
}

void NV_API_CALL nv_dma_release_sgt
(
    struct sg_table *sgt,
    struct drm_gem_object *gem
)
{
    if (gem == NULL)
    {
        return;
    }

    // Do nothing with SGT, it will be unmapped and unpinned by the exporter
    WARN_ON(sgt == NULL);

    nv_dma_gem_object_put_unlocked(gem);

    module_put(gem->dev->driver->fops->owner);
}

#else

NV_STATUS NV_API_CALL nv_dma_import_sgt
(
    nv_dma_device_t *dma_dev,
    struct sg_table *sgt,
    struct drm_gem_object *gem
)
{
    return NV_ERR_NOT_SUPPORTED;
}

void NV_API_CALL nv_dma_release_sgt
(
    struct sg_table *sgt,
    struct drm_gem_object *gem
)
{
}
#endif /* IS_ENABLED(CONFIG_DRM) */

static NvBool nv_is_dma_domain
(
    nv_state_t *nv
)
{
    nv_linux_state_t *nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    struct iommu_domain *domain = iommu_get_domain_for_dev(nvl->dev);

    if (domain == NULL)
    {
        return NV_FALSE;
    }

#if defined(NV_IOMMU_IS_DMA_DOMAIN_PRESENT)
    return iommu_is_dma_domain(domain);
#else
    return (domain->type & __IOMMU_DOMAIN_DMA_API) != 0;
#endif
}

static NV_STATUS _nv_dma_get_sysmem_range
(
    nv_state_t *nv,
    NvU64      *phys_base,
    NvU64      *size
)
{
    NvS32 node_id = nv->cpu_numa_node_id;
    NvU64 start_pfn = NV_U64_MAX;
    NvU64 end_pfn = 0ULL;
    struct zone *zone;
    struct pglist_data *pgdat;
    NvU32 zone_id;

    if (node_id < 0 || !node_online(node_id))
    {
        return NV_ERR_NOT_SUPPORTED;
    }

    //
    // UVM uses ZONE_DEVICE for coherent device pages which adds into the
    // available sysmem and the inflated size is included in sysmem accounting
    // if node_start_pfn/node_end_pfn are used directly.
    // Instead, compute the sysmem range from managed, non-ZONE_DEVICE zones
    // so device PFNs don't inflate the result.
    //
    pgdat = NODE_DATA(node_id);
    for (zone_id = 0; zone_id < MAX_NR_ZONES; zone_id++)
    {
#ifdef CONFIG_ZONE_DEVICE
        if (zone_id == ZONE_DEVICE)
            continue;
#endif
        zone = &(pgdat->node_zones[zone_id]);
        if (!managed_zone(zone))
            continue;

        start_pfn = min(start_pfn, (NvU64)zone->zone_start_pfn);
        end_pfn   = max(end_pfn,   (NvU64)zone_end_pfn(zone));
    }

    if (start_pfn >= end_pfn)
    {
        return NV_ERR_NOT_SUPPORTED;
    }

    *phys_base = start_pfn << PAGE_SHIFT;
    *size      = (end_pfn - start_pfn) << PAGE_SHIFT;

    return NV_OK;
}

static NV_STATUS nv_dma_map_sysmem_dynamic
(
    nv_state_t *nv,
    NvU64       phys_size,
    NvU64      *dma_addr,
    NvU64      *dma_size
)
{
#if NV_IS_EXPORT_SYMBOL_GPL_dma_iova_try_alloc
    nv_linux_state_t *nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    struct dma_iova_state state;

    if (!dma_iova_try_alloc(nvl->dev, &state, 0, phys_size))
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "Failed to allocate IOVA region for sysmem size 0x%llx\n",
                      phys_size);

        return NV_ERR_OPERATING_SYSTEM;
    }

    *dma_addr     = (NvU64)state.addr;
    *dma_size     = (NvU64)dma_iova_size(&state);

    NV_DEV_PRINTF(NV_DBG_INFO, nv,
                  "Sysmem mapped in DMA domain, IOVA base: 0x%llx size: 0x%llx\n",
                  *dma_addr, *dma_size);

    return NV_OK;
#else
    return NV_ERR_NOT_SUPPORTED;
#endif // NV_IS_EXPORT_SYMBOL_GPL_dma_iova_try_alloc
}

static NV_STATUS nv_dma_map_sysmem_identity
(
    nv_state_t *nv,
    NvU64       phys_base,
    NvU64       phys_size,
    NvU64      *dma_addr,
    NvU64      *dma_size
)
{
    nv_linux_state_t *nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    dma_addr_t addr;

    addr = dma_map_single(nvl->dev, phys_to_virt(phys_base),
                          phys_size, DMA_BIDIRECTIONAL);
    if (dma_mapping_error(nvl->dev, addr))
    {
        NV_DEV_PRINTF(NV_DBG_ERRORS, nv,
                      "Local CPU NUMA sysmem mapping failed for phys: 0x%llx size: 0x%llx\n",
                      phys_base, phys_size);

        return NV_ERR_OPERATING_SYSTEM;
    }

    *dma_addr     = (NvU64)addr;
    *dma_size     = phys_size;

    NV_DEV_PRINTF(NV_DBG_INFO, nv,
                  "Local CPU NUMA sysmem mapped in identity/off mode, addr: 0x%llx size: 0x%llx\n",
                  *dma_addr, *dma_size);

    return NV_OK;
}

NV_STATUS NV_API_CALL nv_dma_init_sysmem_window_for_fabric_access
(
    nv_state_t *nv,
    NvU64       alignment,
    NvU64      *dma_addr,
    NvU64      *dma_size,
    NvBool     *dma_identity
)
{
    NvU64 sysmem_base, sysmem_size;
    NV_STATUS status;

    if ((dma_addr == NULL) ||
        (dma_size == NULL) ||
        (dma_identity == NULL) ||
        (alignment == 0))
    {
        return NV_ERR_INVALID_ARGUMENT;
    }

    status = _nv_dma_get_sysmem_range(nv, &sysmem_base, &sysmem_size);
    if (status != NV_OK)
    {
        return status;
    }
    else if (sysmem_size == 0)
    {
        return NV_ERR_INVALID_STATE;
    }

    NV_DEV_PRINTF(NV_DBG_INFO, nv,
                  "Local CPU NUMA sysmem phys base: 0x%llx size: 0x%llx\n",
                  sysmem_base, sysmem_size);

    if (nv_is_dma_domain(nv))
    {
        status = nv_dma_map_sysmem_dynamic(nv, NV_ALIGN_UP64(sysmem_size, alignment),
                                           dma_addr, dma_size);
        *dma_identity = NV_FALSE;
    }
    else
    {
        status = nv_dma_map_sysmem_identity(nv, sysmem_base, sysmem_size,
                                            dma_addr, dma_size);
        *dma_identity = NV_TRUE;
    }

    return status;
}

void NV_API_CALL nv_dma_destroy_sysmem_window_for_fabric_access
(
    nv_state_t *nv,
    NvU64       dma_addr,
    NvU64       dma_size
)
{
    nv_linux_state_t *nvl = NV_GET_NVL_FROM_NV_STATE(nv);
    struct device *dev = nvl->dev;

    if (!nv_is_dma_domain(nv))
    {
        NV_DEV_PRINTF(NV_DBG_INFO, nv,
                      "Unmapping local CPU NUMA sysmem DMA addr: 0x%llx size: 0x%llx\n",
                      dma_addr, dma_size);

        dma_unmap_single(dev, (dma_addr_t)dma_addr,
                         (size_t)dma_size, DMA_BIDIRECTIONAL);
    }
    else
    {
#if NV_IS_EXPORT_SYMBOL_GPL_dma_iova_try_alloc
        struct dma_iova_state state;

        state.addr   = (dma_addr_t)dma_addr;
        state.__size = (u64)dma_size;

        NV_DEV_PRINTF(NV_DBG_INFO, nv,
                      "Freeing local NUMA sysmem IOVA range addr: 0x%llx size: 0x%llx\n",
                      dma_addr, dma_size);

        dma_iova_free(dev, &state);
#endif
    }
}
